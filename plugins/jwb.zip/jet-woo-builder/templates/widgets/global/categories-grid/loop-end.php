<?php
/**
 * JetWooBuilder Categories Grid widget loop end template.
 *
 * This template can be overridden by copying it to yourtheme/jet-woo-builder/widgets/global/categories-grid/loop-end.php.
 */
?>
</div>
