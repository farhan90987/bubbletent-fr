<?php
/* 
/* Define plugin variables
*/
define( 'WC_J_UPSELLATOR_VERSION', '3.3.7' );
define( 'WC_J_UPSELLATOR_TEXTDOMAIN', 'woo_j_cart' );
define( 'WC_J_UPSELLATOR_PLUGIN_NAME', 'J Cart Upsell and cross-sell' );
define( 'WC_J_UPSELLATOR_ITEM_SLUG', 'wc-j-upsellator');
