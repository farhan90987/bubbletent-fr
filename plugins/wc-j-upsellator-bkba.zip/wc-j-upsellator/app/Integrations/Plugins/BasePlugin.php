<?php

namespace WcJUpsellator\Integrations\Plugins;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class BasePlugin
{

}
