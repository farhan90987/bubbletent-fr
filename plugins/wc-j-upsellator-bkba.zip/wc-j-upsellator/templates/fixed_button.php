<div class="wc-timeline-button-show-cart wc-j-upsellator-show-cart flex-column-center <?php echo esc_attr(  woo_j_conf('position') ) ?>">
		
		<i class="<?php echo esc_attr( woo_j_styles('modal_icon') ) ?>"></i>
		<div class="wc-item-count"><?php echo $count ?></div>

</div>